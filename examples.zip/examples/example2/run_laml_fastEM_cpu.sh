python ../../run_laml.py -c character_matrix.csv -t starting.tree -p priors.csv -o example2_fastEM_cpu --nInitials 1 --randomreps 5 --topology_search -v --solver "fastEM-cpu" --timescale 10
